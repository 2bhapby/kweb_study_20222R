const ArticleDAO = require('./article');
const UserDAO = require('./user');

module.exports = {ArticleDAO, UserDAO};