const { ArticleDAO } = require('../../DAO');
const { verifyToken } = require('../../lib/jwt');

const readArticle = async (req, res, next) => {
	try{
		const { articleId } = req.params;
		const { user } = await verifyToken(req.cookies.jwtToken);

		const article = await ArticleDAO.getById(articleId);
		if (!article) throw new Error('NOT_EXIST');

		return res.render('articles/details.pug', { user, article });
	}catch (err) {
			return next(err);
	}
};

const writeArticleForm = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		return res.render('articles/editor.pug', { user });
	} catch(err){
		return next(err);
	}
};

const writeArticle = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		console.log(user);
		const { title , content } = req.body;

		const trimmedTitle = title.trim();
		const trimmedContent = content.trim();

		if (
			!trimmedTitle ||
			trimmedTitle.length > 50 ||
			!trimmedContent ||
			trimmedContent.length > 65535) throw new Error('BAD_REQUEST');
		
		const newArticleId = await ArticleDAO.create(trimmedTitle, trimmedContent, user);

		return res.redirect(`/article/${newArticleId}`);
	} catch(err){
		return next(err);
	}
};

const editArticleForm = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		const { articleId } = req.params;
		console.log(articleId);

		const article = await ArticleDAO.getByIdAndAuthor(articleId, user.id);
		if(!article) throw new Error('NOT_EXIST');
		
		return res.render('articles/editor.pug', { user, article });
	} catch(err){
		return next(err);
	}
};

const editArticle = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		const { title , content } = req.body;
		const { articleId } = req.params;

		const trimmedTitle = title.trim();
		const trimmedContent = content.trim();

		if (
			!trimmedTitle ||
			trimmedTitle.length > 50 ||
			!trimmedContent ||
			trimmedContent.length > 65535) throw new Error('BAD_REQUEST');

		const article = await ArticleDAO.getByIdAndAuthor(articleId, user.id);
		if(!article) throw new Error('NOT_EXIST');
	
			
		await ArticleDAO.update(articleId, trimmedTitle, trimmedContent);

		return res.redirect(`/article/${articleId}`);
	} catch(err){
		return next(err);
	}
};

const deleteArticle = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		const {articleId} = req.params;

		console.log(articleId);
		const article = await ArticleDAO.getByIdAndAuthor(articleId, user.id);
		if(!article) throw new Error('NOT_EXIST');
		
		await ArticleDAO.remove(articleId);

		return res.redirect('/articles');
	} catch(err){
		return next(err);
	}
};

module.exports = {
	readArticle,
	writeArticleForm,
	writeArticle,
	editArticleForm,
	editArticle,
	deleteArticle,
};