//const jwt = require('jsonwebtoken');

const { verifyToken } = require("../../lib/jwt");

const authRequired = async(req, res, next) => {
	try{
		if (req.cookies.user) return next();
		else throw new Error('NOT_EXIST');
	}	
	catch (err) {
		throw err;
	}
};

const authToken = (req, res, next) => {
    // 인증 완료
        // 요청 헤더에 저장된 토큰(req.headers.authorization)과 비밀키를 사용하여 토큰을 req.decoded에 반환
        // req.decoded = jwt.verify(req.headers.authorization, JWT_KEY);
        // 쿠키에 user 이름으로 JWT 저장
	try{
		console.log(req.cookies);
		const decoded = verifyToken(req.cookies.jwtToken);
		req.id = decoded.id;
		req.displayName = decoded.displayName;
		return next();
	}
	catch (err) {
		throw err;
	}
}


module.exports = { authRequired, authToken };