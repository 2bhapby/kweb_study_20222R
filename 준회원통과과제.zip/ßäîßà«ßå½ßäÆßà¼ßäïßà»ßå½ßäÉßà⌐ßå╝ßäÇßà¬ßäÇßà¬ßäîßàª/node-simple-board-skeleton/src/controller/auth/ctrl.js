const { UserDAO } = require('../../DAO');
const { verifyPassword, generatePassword } = require('../../lib/authentication');
const { tokenGenerator, verifyToken } = require('../../lib/jwt');
//const { authToken } = require('./middleware');



const signInForm = async (req, res, next) => {
	try {
		const { user } = await verifyToken(req.cookies.jwtToken);
		if (user) return res.redirect('/');
		else return res.render('auth/sign-in.pug', { user });
	}catch (err) {
		return next(err);
	}
};

const signIn = async (req, res, next) => {
	try{
	/* user정보를 DB에서 조회 */
		const { username, password } = req.body;
		if (!username || !password) throw new Error('BAD_REQUEST');

		const user = await UserDAO.getByUsername(username);
		if (!user) throw new Error('UNAUTHORIZED');
		const isValid = await verifyPassword(password, user.password);
		if (!isValid) throw new Error('UNAUTHORIZED');
		//const user = await User.getUserByEmail(email);
		/* user의 idx, email을 통해 토큰을 생성! */
		const jwtToken = await tokenGenerator(user);
		// req.cookies.user = {
		// 	id: user.id,
		// 	username,
		// 	displayName: user.displayName,
		// 	isActive: user.isActive,
		// 	isStaff: user.isStaff,
		// };
		return res.cookie('jwtToken', jwtToken, {
			httpOnly: true,
			secure: process.env.NODE_ENV === "production",
		  }).redirect('/');
		// return res.status(statusCode.OK).send(util.success(statusCode.OK, responseMsg.LOGIN_SUCCESS, {
		// 	/* 생성된 Token을 클라이언트에게 Response */
		// 	token: jwtToken.token
		// }))
		// req.session.user = {
		// 	id: user.id,
		// 	username,
		// 	displayName: user.displayName,
		// 	isActive: user.isActive,
		// 	isStaff: user.isStaff,
		// };
	}catch (err) {
		return next(err);
	}
};

const signUpForm = async (req, res, next) => {
	try {
		const { user } = req.cookies;
		
		return res.render('auth/sign-up.pug', { user });
	}catch (err) {
		return next(err);
	}
};

const signUp = async (req, res, next) => {
	try {
		const { username, password, displayName } = req.body;
		if (!username || !password || !displayName || username.length > 16 || password.length > 151 || displayName.length > 32) throw new Error('BAD_REQUEST');

		const genPassword = await generatePassword(password);
		await UserDAO.create(username, genPassword, displayName);
	
		return res.redirect('/auth/sign_in');
	}catch (err) {
		return next(err);
	}
};

const signOut = async (req, res, next) => {
	try{
		res.clearCookie('jwtToken').redirect('/');
	}catch(err) {
		return next(err);
	}
};

module.exports = {
	signInForm,
	signIn,
	signUpForm,
	signUp,
	signOut,
}