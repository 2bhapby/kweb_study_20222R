ClassicEditor
    .create(document.querySelector('#editor'))
    .catch(err => console.error(err));
